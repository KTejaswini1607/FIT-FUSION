package `in`.starbow.fitindia.callback

interface stepsCallback {

    fun subscribeSteps(steps: Int)
}